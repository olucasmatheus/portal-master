import * as UserComponent from './User/';
import * as EstagiarioComponent from './Estagiario/';

export { UserComponent, EstagiarioComponent };
