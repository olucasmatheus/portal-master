import { Request } from 'express';

export interface IGetId extends Request {
    user: any;
}
